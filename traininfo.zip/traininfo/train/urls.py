from django.contrib import admin
from django.urls import path,include
from . import views
from traininfo.settings import DEBUG, STATIC_URL, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static



urlpatterns = [
    path('', views.home, name='home'),
    path('upload',views.upload,name='upload'),
    path('update/<int:train_id>',views.update_train),
    path('delete/<int:train_id>',views.delete_train),

]



if DEBUG:
    urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)