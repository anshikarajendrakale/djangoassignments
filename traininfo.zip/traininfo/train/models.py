from django.db import models


# Create your models here.
class Train(models.Model):
    name = models.CharField(max_length=100)
    arrival= models.CharField(max_length=100)
    departure= models.TextField(max_length=100)
    departure_time=models.CharField(max_length=100)
    arrival_time=models.CharField(max_length=100)
    picture = models.ImageField(max_length=100)

    def __str__(self):
        return self.name