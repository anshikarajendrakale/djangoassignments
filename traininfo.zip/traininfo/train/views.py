from django.shortcuts import render, HttpResponse, redirect
from .models import Train
from .forms import TrainForm


# Create your views here.
def home(request):
    trains= Train.objects.all();
    return render(request, 'index.html', {'trains_list': trains})


def upload(request):
    # GET localhost:8000/upload
    upload = TrainForm()  # empty BookForm displayed , new instance

    # POST - now BookForm filled fields and submitted
    if request.method == 'POST':
        upload = TrainForm(request.POST, request.FILES)

        if upload.is_valid():
            upload.save()
            return redirect('home')
        else:
            return HttpResponse("<h2>Error: You have not filled correct information</h2>")

    else:
        return render(request, 'upload.html', {'upload_form': upload})


def update_train(request, train_id):
    train_id = int(train_id)

    try:
        train_select = Train.objects.get(id=train_id)
    except Train.DoesNotExist:
        return redirect('home')

    train_form = TrainForm(request.POST or None, instance=train_select)
    if train_form.is_valid():
        train_form.save()
        return redirect('home')
    else:
        return render(request, 'upload.html', {'upload_form': train_form})


def delete_train(request, train_id):
    train_id = int(train_id)

    try:
        train_select = Train.objects.get(id=train_id)
    except Train.DoesNotExist:
        return redirect('home')

    train_select.delete()
    return redirect('home')



