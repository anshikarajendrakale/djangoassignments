from django.contrib import admin
from .models import Train

# Register your models here.
admin.site.register(Train)