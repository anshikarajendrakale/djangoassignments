from django.urls import path
from .api import StudCreateApi, StudApi, StudUpdateApi, StudDeleteApi

urlpatterns = [
    #path('/home',views.home) function based view
    path('api',StudApi.as_view()),
    path('api/create',StudCreateApi.as_view()),
    path('api/<int:pk>',StudUpdateApi.as_view()),
    path('api/<int:pk>/delete',StudDeleteApi.as_view()),
]