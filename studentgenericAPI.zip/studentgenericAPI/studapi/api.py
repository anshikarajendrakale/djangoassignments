from rest_framework import generics
from rest_framework.response import Response
from .serializer import StudSerializer
from .models import student

class StudCreateApi(generics.CreateAPIView):
    queryset = student.objects.all()
    serializer_class = StudSerializer

class StudApi(generics.ListAPIView):
    queryset = student.objects.all()
    serializer_class = StudSerializer

class StudUpdateApi(generics.RetrieveUpdateAPIView):
    queryset = student.objects.all()
    serializer_class = StudSerializer

class StudDeleteApi(generics.DestroyAPIView):
    queryset = student.objects.all()
    serializer_class = StudSerializer