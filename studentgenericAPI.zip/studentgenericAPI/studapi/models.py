from django.db import models

# Create your models here.
class student(models.Model):
    student_rollno=models.TextField(unique=True)
    student_name=models.TextField()
    student_email=models.TextField()
    student_mobile=models.TextField(null=True)
    student_aggregate=models.IntegerField()
