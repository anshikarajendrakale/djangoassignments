from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Employee
from .serializers import EmployeeSerializer


# Create your views here.
class EmployeeList(APIView):

    def get(self, request):
        Employees = Employee.objects.all()
        ser = EmployeeSerializer(Employees, many=True)
        return Response(ser.data)  ## return JSON

    def post(self):
        pass